"""Tracked REC-3 four-condition protocol orchestration."""

from .orchestrator import run_active_profile

__all__ = ["run_active_profile"]
