"""Seal REC-3 mock10 evidence, including failing quality evidence, for review."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
import time
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
ARTIFACT_ROOT = ROOT / "docs/artifacts/rec3-four-condition-mock10"
EVIDENCE = ROOT / "docs/artifacts/review-pack/rec3-four-condition-mock10"
ARCHIVE = ROOT / "docs/reviews/review-pack-rec3-protocol-four-conditions-mock10.tar.gz"
SOURCE_FILES = [
    ".gitignore", "config.yml", "pyproject.toml",
    "src/ccdf/compression/__init__.py", "src/ccdf/compression/llmlingua.py", "src/ccdf/compression/schemas.py",
    "src/ccdf/runtime/engine.py", "src/ccdf/inference/baseline.py", "src/ccdf/dflash/generate.py",
    "src/ccdf/schemas.py", "src/ccdf/device.py",
    "tests/run_rec3_four_condition_protocol.py", "tests/build_rec3_four_condition_review_pack.py",
    "tests/run_rec3_mock02_divergence.py", "tests/test_rec3_protocol_helpers.py",
    "tests/test_compression_protocol.py", "tests/test_dflash_integration.py", "tests/test_metrics.py",
]
ARTIFACT_FILES = [
    "docs/artifacts/rec3-four-condition-mock10/mock_fixtures.json",
    "docs/artifacts/rec3-four-condition-mock10/raw_runs.json",
    "docs/artifacts/rec3-four-condition-mock10/summary.json",
    "docs/artifacts/rec3-four-condition-mock10/rec3_mock_02_divergence.json",
    "docs/artifacts/rec3-four-condition-mock10/BLOCKER.md",
]


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _write(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value, encoding="utf-8")


def _run(label: str, command: list[str], environment: dict[str, str]) -> dict[str, Any]:
    started = time.perf_counter()
    completed = subprocess.run(command, cwd=ROOT, env=environment, text=True, capture_output=True, check=False)
    return {
        "label": label, "command": command, "exit_code": completed.returncode,
        "stdout": completed.stdout, "stderr": completed.stderr,
        "duration_seconds": time.perf_counter() - started,
    }


def _checkpoint_manifest() -> dict[str, Any]:
    from ccdf.config import load_config

    config = load_config(ROOT / "config.yml")
    entries: dict[str, Any] = {}
    for label, key in {
        "baseline": "models.baseline.local_path", "dflash_target": "models.dflash.target.local_path",
        "dflash_drafter": "models.dflash.drafter.local_path", "compressor": "models.compressor.local_path",
    }.items():
        directory = config.path_for(key)
        files = []
        for item in sorted(directory.iterdir()):
            if not item.is_file():
                continue
            if item.name in {"config.json", "generation_config.json"}:
                category = "config"
            elif item.name.startswith("tokenizer") or item.name in {"special_tokens_map.json", "vocab.json", "merges.txt"}:
                category = "tokenizer"
            elif item.suffix in {".safetensors", ".bin", ".pt", ".pth"}:
                category = "weights"
            else:
                continue
            files.append({"filename": item.name, "category": category, "bytes": item.stat().st_size, "sha256": _sha256(item)})
        entries[label] = {"path": str(directory.relative_to(ROOT)), "files": files}
    return {
        "manifest_version": "ccdf.rec3-checkpoint-manifest.v2",
        "models": entries,
        "archive_policy": "Only checkpoint metadata and SHA-256 values are included; no model file is archived.",
    }


def _git_evidence(environment: dict[str, str]) -> tuple[str, str]:
    base = _run("base-commit", ["git", "rev-parse", "HEAD"], environment)
    if base["exit_code"] != 0:
        raise RuntimeError(f"cannot resolve base commit: {base['stderr']}")
    base_sha = str(base["stdout"]).strip()
    changed = [
        _run("git-diff-name-status", ["git", "diff", "--name-status", base_sha], environment),
        _run("git-diff-cached-name-status", ["git", "diff", "--cached", "--name-status", base_sha], environment),
        _run("git-untracked", ["git", "ls-files", "--others", "--exclude-standard"], environment),
        _run("git-status", ["git", "status", "--short", "--untracked-files=all"], environment),
        _run(
            "git-ignored-validation-sources",
            [
                "git", "check-ignore", "-v",
                "tests/run_rec3_four_condition_protocol.py",
                "tests/run_rec3_mock02_divergence.py",
                "tests/build_rec3_four_condition_review_pack.py",
                "tests/test_rec3_protocol_helpers.py",
            ],
            environment,
        ),
    ]
    changed_text = "".join(
        f"# {item['label']}\n$ {' '.join(item['command'])}\nexit={item['exit_code']}\n{item['stdout']}{item['stderr']}\n"
        for item in changed
    )
    proof = [
        _run("dflash-status", ["git", "status", "--short", "--", "src/ccdf/dflash"], environment),
        _run("dflash-diff-numstat", ["git", "diff", "--numstat", base_sha, "--", "src/ccdf/dflash"], environment),
        _run("dflash-untracked", ["git", "ls-files", "--others", "--exclude-standard", "src/ccdf/dflash"], environment),
        _run("dflash-diff-check", ["git", "diff", "--check", base_sha, "--", "src/ccdf/dflash"], environment),
    ]
    proof_text = (
        f"base_commit_sha={base_sha}\n"
        "scope=src/ccdf/dflash (D-Flash core)\n"
        "claim=No D-Flash core change is included in this REC-3 validation work.\n\n"
        + "".join(
            f"# {item['label']}\n$ {' '.join(item['command'])}\nexit={item['exit_code']}\n{item['stdout']}{item['stderr']}\n"
            for item in proof
        )
    )
    return base_sha, changed_text + "\n", proof_text


def main() -> None:
    environment = os.environ.copy()
    environment["PROJECT_ROOT"] = str(ROOT)
    EVIDENCE.mkdir(parents=True, exist_ok=True)
    commands = [
        _run("rec3-four-condition-protocol", [str(ROOT / ".venv/bin/python"), "tests/run_rec3_four_condition_protocol.py"], environment),
        _run("rec3-mock02-divergence", [str(ROOT / ".venv/bin/python"), "tests/run_rec3_mock02_divergence.py"], environment),
        _run("compileall", [str(ROOT / ".venv/bin/python"), "-m", "compileall", "-q", "src", "scripts", "tests"], environment),
        _run("pytest", [str(ROOT / ".venv/bin/pytest"), "-q"], environment),
        _run("git-diff-check", ["git", "diff", "--check"], environment),
    ]
    _write(EVIDENCE / "commands.json", json.dumps(commands, indent=2, sort_keys=True) + "\n")
    _write(EVIDENCE / "test-results.txt", "".join(
        f"$ {' '.join(entry['command'])}\nexit={entry['exit_code']}\n{entry['stdout']}{entry['stderr']}\n"
        for entry in commands
    ))
    status = _run("git-status", ["git", "status", "--short", "--untracked-files=all"], environment)
    diff = _run("git-diff", ["git", "diff", "--no-ext-diff"], environment)
    _write(EVIDENCE / "git-status.txt", str(status["stdout"]))
    _write(EVIDENCE / "git-diff.patch", str(diff["stdout"]))
    _write(EVIDENCE / "checkpoint-manifest.json", json.dumps(_checkpoint_manifest(), indent=2, sort_keys=True) + "\n")
    base_sha, changed_text, dflash_proof = _git_evidence(environment)
    _write(EVIDENCE / "base-commit.txt", base_sha + "\n")
    _write(EVIDENCE / "changed-files.txt", changed_text)
    _write(EVIDENCE / "dflash-core-diff-proof.txt", dflash_proof)

    summary_path = ARTIFACT_ROOT / "summary.json"
    protocol_summary: dict[str, Any] = {}
    if summary_path.is_file():
        protocol_summary = json.loads(summary_path.read_text(encoding="utf-8"))
    gates = {
        "protocol_pass": protocol_summary.get("protocol_pass") is True,
        "quality_pass": protocol_summary.get("quality_pass") is True,
        "metric_validity_pass": protocol_summary.get("metric_validity_pass") is True,
        "overall_pass": protocol_summary.get("overall_pass") is True,
        "fresh_protocol_command_pass": commands[0]["exit_code"] == 0,
        "divergence_diagnostic_pass": commands[1]["exit_code"] == 0,
        "compileall_pass": commands[2]["exit_code"] == 0,
        "pytest_pass": commands[3]["exit_code"] == 0,
        "git_diff_check_pass": commands[4]["exit_code"] == 0,
    }
    _write(EVIDENCE / "validation-summary.json", json.dumps({"pass": all(gates.values()), "gates": gates, "protocol_summary": protocol_summary}, indent=2, sort_keys=True) + "\n")

    required = [ROOT / name for name in SOURCE_FILES]
    optional = [ROOT / name for name in ARTIFACT_FILES if (ROOT / name).is_file()]
    manifest_path = EVIDENCE / "archive-manifest.json"
    pack_members_path = EVIDENCE / "pack-members.txt"
    members = [*required, *optional]
    members.extend(path for path in EVIDENCE.rglob("*") if path.is_file() and path not in {manifest_path, pack_members_path})
    missing = [str(path.relative_to(ROOT)) for path in required if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"required review-pack source missing: {missing}")
    forbidden_prefixes = ("models/", "data/raw/", "data/processed/", ".venv/", ".git/", "__pycache__/")
    relative = [str(path.relative_to(ROOT)) for path in members]
    if any(name.startswith(forbidden_prefixes) or name.endswith(".tar.gz") for name in relative):
        raise RuntimeError("review pack member violates exclusion policy")
    planned_members = sorted({*relative, str(pack_members_path.relative_to(ROOT)), str(manifest_path.relative_to(ROOT))})
    _write(pack_members_path, "\n".join(planned_members) + "\n")
    members.append(pack_members_path)
    manifest = {
        "manifest_version": "ccdf.rec3-four-condition-review-pack.v2",
        "base_commit_sha": base_sha,
        "self_entry_policy": "archive-manifest.json is omitted from its own hash map to avoid recursive hashing",
        "members": {
            str(path.relative_to(ROOT)): {"bytes": path.stat().st_size, "sha256": _sha256(path)}
            for path in sorted(set(members))
        },
    }
    _write(manifest_path, json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    all_members = [*members, manifest_path]
    ARCHIVE.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(ARCHIVE, "w:gz") as archive:
        for path in sorted(set(all_members)):
            archive.add(path, arcname=str(path.relative_to(ROOT)), recursive=False)

    with tempfile.TemporaryDirectory(prefix="ccdf-rec3-pack-check-") as temporary:
        with tarfile.open(ARCHIVE, "r:gz") as archive:
            archived = [entry.name for entry in archive.getmembers() if entry.isfile()]
            if any(name.startswith(forbidden_prefixes) or name.endswith(".tar.gz") for name in archived):
                raise RuntimeError("sealed archive violates exclusion policy")
            archive.extractall(temporary, filter="data")
        temporary_root = Path(temporary)
        sealed_manifest = json.loads((temporary_root / manifest_path.relative_to(ROOT)).read_text(encoding="utf-8"))
        expected_names = sorted([*sealed_manifest["members"], str(manifest_path.relative_to(ROOT))])
        if sorted(archived) != expected_names:
            raise RuntimeError("sealed archive members differ from manifest")
        pack_members = (temporary_root / pack_members_path.relative_to(ROOT)).read_text(encoding="utf-8").splitlines()
        if sorted(pack_members) != expected_names:
            raise RuntimeError("pack-members.txt differs from sealed archive membership")
        verified = {
            name: {
                "bytes": (temporary_root / name).stat().st_size,
                "sha256": _sha256(temporary_root / name),
            } == expected
            for name, expected in sealed_manifest["members"].items()
        }
        if not all(verified.values()):
            raise RuntimeError(f"sealed archive hash failure: {[name for name, passed in verified.items() if not passed]}")
    result = {
        "pass": all(gates.values()), "archive": str(ARCHIVE), "archive_sha256": _sha256(ARCHIVE),
        "base_commit_sha": base_sha, "member_count": len(archived),
        "manifest_hashes_verified": f"{sum(verified.values())}/{len(verified)}", "gates": gates,
    }
    print(json.dumps(result, sort_keys=True))
    if not result["pass"]:
        raise SystemExit("REC-3 review pack contains a failing protocol, quality, or metric gate")


if __name__ == "__main__":
    main()
