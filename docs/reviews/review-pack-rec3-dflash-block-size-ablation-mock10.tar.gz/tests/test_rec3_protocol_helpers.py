import importlib.util
from pathlib import Path


RUNNER = Path(__file__).with_name("run_rec3_four_condition_protocol.py")
SPEC = importlib.util.spec_from_file_location("rec3_protocol_runner", RUNNER)
assert SPEC is not None and SPEC.loader is not None
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def test_tolerant_parser_keeps_fields_when_strict_format_rejects_punctuation():
    expected = {"owner": "Hana", "approval_code": "AP-708", "quantity": "168"}

    result = MODULE._output_quality_record(
        "Owner: Hana; Approval code: AP-708; Quantity: 168.", expected
    )

    assert result["format_compliant"] is False
    assert result["parsed_fields"] == expected
    assert result["exact_field_match"] is True


def test_tolerant_parser_still_rejects_wrong_field_value_for_quality():
    expected = {"owner": "Binh", "approval_code": "AP-702", "quantity": "58"}

    result = MODULE._output_quality_record(
        "Owner: Candidate-2; Approval code: AP-702; Quantity: 58", expected
    )

    assert result["format_compliant"] is True
    assert result["parsed_fields"]["owner"] == "Candidate-2"
    assert result["field_matches"]["owner"] is False
    assert result["exact_field_match"] is False
