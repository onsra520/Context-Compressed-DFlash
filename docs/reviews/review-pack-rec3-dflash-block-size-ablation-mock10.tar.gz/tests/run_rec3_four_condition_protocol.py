"""Validate the REC-3 four-condition mock protocol without changing D-Flash.

This validation-only runner makes compressor and generation residency explicit:
compress all contexts on CUDA, unload the compressor, then load one generation
engine at a time.  It intentionally preserves the frozen ten fixtures and
reports protocol, output-quality, and metric-validity gates independently.
"""

from __future__ import annotations

import copy
import hashlib
from importlib import metadata as importlib_metadata
import json
import os
from pathlib import Path
import platform
import re
import statistics
import subprocess
import sys
import time
from typing import Any

import torch
import transformers


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
os.environ.setdefault("PROJECT_ROOT", str(ROOT))

from ccdf.compression import CompressionConfig, ContextOnlyProtocol, LLMLinguaCompressor  # noqa: E402
from ccdf.config import Rec2Config, load_config  # noqa: E402
from ccdf.device import synchronize  # noqa: E402
from ccdf.runtime.engine import RuntimeEngine  # noqa: E402


OUTPUT_DIR = ROOT / "docs/artifacts/rec3-four-condition-mock10"
RAW_OUTPUT = OUTPUT_DIR / "raw_runs.json"
SUMMARY_OUTPUT = OUTPUT_DIR / "summary.json"
FIXTURES_OUTPUT = OUTPUT_DIR / "mock_fixtures.json"
MAX_NEW_TOKENS = 32
COMPRESSION_CONFIG = CompressionConfig(keep_rate=0.5, chunk_max_words=180)
NEUTRAL_SYSTEM_PROMPT = (
    "You are an information extraction assistant. Return only the requested output format."
)
STRICT_OUTPUT_FORMAT = re.compile(
    r"^Owner: (?P<owner>[^;\r\n]+); Approval code: (?P<approval_code>[^;\r\n]+); Quantity: (?P<quantity>[0-9]+)$"
)
TOLERANT_FIELD_FORMAT = re.compile(
    r"Owner:\s*(?P<owner>[^;\r\n]+);\s*Approval code:\s*(?P<approval_code>[^;\r\n]+);\s*Quantity:\s*(?P<quantity>[0-9]+)"
)
CONDITIONS = (
    "baseline-ar",
    "dflash-r1",
    "llmlingua-ar-r2",
    "cc-dflash-r2",
)
# Frozen REC-3 mock10 fixtures. Do not tune these values to improve a gate.
CASES = (
    (16, 0.15, "Asha", "AP-701", "41"),
    (16, 0.15, "Binh", "AP-702", "58"),
    (20, 0.30, "Chen", "AP-703", "73"),
    (24, 0.45, "Dara", "AP-704", "89"),
    (28, 0.60, "Elena", "AP-705", "104"),
    (32, 0.75, "Farid", "AP-706", "126"),
    (30, 0.90, "Gia", "AP-707", "147"),
    (30, 1.00, "Hana", "AP-708", "168"),
    (18, 0.50, "Ivo", "AP-709", "193"),
    (32, 0.70, "Juno", "AP-710", "215"),
)


def _sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _sha256_text(value: str) -> str:
    return _sha256_bytes(value.encode("utf-8"))


def _token_ids_sha256(token_ids: list[int]) -> str:
    """Hash the exact ordered chat-template token sequence in a portable encoding."""
    return _sha256_bytes(json.dumps(token_ids, separators=(",", ":")).encode("ascii"))


def _cuda_memory(label: str) -> dict[str, Any]:
    synchronize()
    if not torch.cuda.is_available():
        return {"label": label, "cuda_available": False}
    return {
        "label": label,
        "cuda_available": True,
        "allocated_bytes": int(torch.cuda.memory_allocated()),
        "reserved_bytes": int(torch.cuda.memory_reserved()),
        "max_allocated_bytes": int(torch.cuda.max_memory_allocated()),
        "max_reserved_bytes": int(torch.cuda.max_memory_reserved()),
    }


def _distribution_version(*names: str) -> str | None:
    for name in names:
        try:
            return importlib_metadata.version(name)
        except importlib_metadata.PackageNotFoundError:
            continue
    return None


def _gpu_environment() -> dict[str, Any]:
    properties = torch.cuda.get_device_properties(0)
    nvidia_smi: dict[str, Any] = {"available": False}
    try:
        completed = subprocess.run(
            [
                "nvidia-smi", "--query-gpu=driver_version,name,compute_cap,memory.total",
                "--format=csv,noheader,nounits",
            ],
            text=True,
            capture_output=True,
            check=True,
        )
        nvidia_smi = {"available": True, "query": completed.stdout.strip()}
    except (OSError, subprocess.CalledProcessError) as exc:
        nvidia_smi = {"available": False, "error": f"{type(exc).__name__}: {exc}"}
    return {
        "python_version": platform.python_version(),
        "torch_version": torch.__version__,
        "torch_cuda_version": torch.version.cuda,
        "transformers_version": transformers.__version__,
        "llmlingua_version": _distribution_version("llmlingua"),
        "autoawq_version": _distribution_version("autoawq", "autoawq-kernels"),
        "gpu_name": properties.name,
        "gpu_count": torch.cuda.device_count(),
        "gpu_compute_capability": [properties.major, properties.minor],
        "gpu_total_memory_bytes": properties.total_memory,
        "nvidia_smi": nvidia_smi,
    }


def _fixture(index: int, turns: int, position: float, owner: str, code: str, quantity: str) -> dict[str, Any]:
    distractors = [
        (
            f"Meeting turn {turn}: unapproved proposal says owner Candidate-{turn % 7}, "
            f"code ZX-{index}{turn:03d}, quantity {1000 + index * 100 + turn}; this is a distractor."
        )
        for turn in range(1, turns + 1)
    ]
    evidence = (
        f"FINAL APPROVED FACT: the approved owner is {owner}; the approval code is {code}; "
        f"the exact approved quantity is {quantity}."
    )
    insertion = round(len(distractors) * position)
    context = " ".join(distractors[:insertion] + [evidence] + distractors[insertion:])
    protocol = ContextOnlyProtocol(
        context=context,
        question="According to the FINAL APPROVED FACT, who is the owner, what is the approval code, and what exact quantity was approved?",
        output_instruction="Return exactly: Owner: <name>; Approval code: <code>; Quantity: <integer>",
    )
    return {
        "prompt_id": f"rec3_mock_{index:02d}",
        "context_turns": turns,
        "evidence_position_fraction": position,
        "expected_fields": {"owner": owner, "approval_code": code, "quantity": quantity},
        "context": context,
        "question": protocol.question,
        "output_instruction": protocol.output_instruction,
        "protocol": protocol,
    }


def _json_fixture(item: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in item.items() if key != "protocol"}


def _mock_config(config: Rec2Config) -> Rec2Config:
    data = copy.deepcopy(config.data)
    data.setdefault("prompts", {})["system"] = NEUTRAL_SYSTEM_PROMPT
    return Rec2Config(path=config.path, root=config.root, data=data)


def _capture_chat_template_input(engine: RuntimeEngine, prompt: str) -> dict[str, Any]:
    """Capture the exact tokenizer output that production generation will receive."""
    token_tensor = engine.encode_prompt(prompt)
    synchronize()
    token_ids = [int(value) for value in token_tensor.detach().cpu().reshape(-1).tolist()]
    del token_tensor
    return {
        "token_ids": token_ids,
        "token_count": len(token_ids),
        "token_ids_sha256": _token_ids_sha256(token_ids),
        "tokenizer_name_or_path": str(getattr(engine.tokenizer, "name_or_path", "")),
        "hash_encoding": "sha256(canonical JSON array of ordered integer token IDs)",
    }


def _request_record(
    *,
    condition: str,
    prompt_kind: str,
    prompt: str,
    compression: dict[str, Any],
    engine: RuntimeEngine,
    lifecycle: list[dict[str, Any]],
) -> dict[str, Any]:
    try:
        chat_input = _capture_chat_template_input(engine, prompt)
        synchronize()
        start = time.perf_counter()
        result = engine.generate(prompt, max_new_tokens=MAX_NEW_TOKENS, temperature=0.0).to_dict()
        synchronize()
        elapsed_ms = (time.perf_counter() - start) * 1000.0
        timing = result["timing"]
        memory = result["memory"]
        compression_ms = float(compression["compression_latency_ms"]) if prompt_kind == "compressed" else 0.0
        request_peak = {
            "peak_allocated_bytes": memory["peak_allocated_bytes"],
            "peak_reserved_bytes": memory["peak_reserved_bytes"],
            "allocated_before_bytes": memory["allocated_before_bytes"],
            "reserved_before_bytes": memory["reserved_before_bytes"],
            "allocated_after_bytes": memory["allocated_after_bytes"],
            "reserved_after_bytes": memory["reserved_after_bytes"],
        }
        compression_peak = {
            "peak_allocated_bytes": compression["peak_allocated_vram_bytes"],
            "peak_reserved_bytes": compression["peak_reserved_vram_bytes"],
        } if prompt_kind == "compressed" else None
        full_request_peak = {
            "peak_allocated_bytes": max(
                request_peak["peak_allocated_bytes"],
                compression_peak["peak_allocated_bytes"] if compression_peak else 0,
            ),
            "peak_reserved_bytes": max(
                request_peak["peak_reserved_bytes"],
                compression_peak["peak_reserved_bytes"] if compression_peak else 0,
            ),
            "measurement_scope": "compression stage plus production generation-request stage; stages use separate GPU residency",
        }
        context_metrics = {
            "context_tokenizer": compression["context_tokenizer"],
            "context_original_tokens": compression["original_tokens"],
            "context_compressed_tokens": compression["compressed_tokens"],
            "context_reduction_rate": compression["reduction_rate"],
        } if prompt_kind == "compressed" else {
            "context_tokenizer": None,
            "context_original_tokens": None,
            "context_compressed_tokens": None,
            "context_reduction_rate": None,
        }
        result["rec3_metrics"] = {
            "raw_rendered_prompt_sha256": _sha256_text(prompt),
            "chat_template_input": chat_input,
            **context_metrics,
            "total_input_token_reduction": None,
            "total_input_token_reduction_scope": "Qwen chat-template input tokens; populated only for compressed conditions",
            "compression_latency_ms": compression_ms,
            "prefill_latency_ms": timing["target_prefill_ms"],
            "draft_prefill_latency_ms": timing["draft_prefill_ms"],
            "decode_latency_ms": timing["decode_total_ms"],
            "generation_latency_ms": timing["generation_total_ms"],
            "stage_sum_warm_e2e_ms": compression_ms + timing["warm_request_ms"],
            "stage_sum_warm_e2e_scope": "sum of separately measured compression stage and synchronized production warm-request stage; excludes model load/unload and warmup",
            "request_wall_clock_ms": elapsed_ms,
            "output_tokens": result["output_tokens"],
            "decode_tok_s": result["metrics"]["decode_tok_s"],
            "cap_hit": result["output_tokens"] >= MAX_NEW_TOKENS or result["stop_reason"] == "max_new_tokens",
            "stage_vram": {"compression": compression_peak, "generation_request": request_peak},
            "generation_request_peak_vram": request_peak,
            "full_request_peak_vram": full_request_peak,
        }
        lifecycle.append({
            "event": "request_complete", "condition": condition, "prompt_kind": prompt_kind,
            "memory": _cuda_memory(f"after_{condition}_{prompt_kind}"),
        })
        return {"success": True, "condition": condition, "prompt_kind": prompt_kind, "result": result}
    except Exception as exc:  # preserve validation evidence even when a condition fails
        is_oom = "out of memory" in str(exc).lower()
        lifecycle.append({
            "event": "request_error", "condition": condition, "prompt_kind": prompt_kind,
            "oom": is_oom, "error": f"{type(exc).__name__}: {exc}", "memory": _cuda_memory("request_error"),
        })
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.ipc_collect()
        return {"success": False, "condition": condition, "prompt_kind": prompt_kind, "oom": is_oom, "error": f"{type(exc).__name__}: {exc}"}


def _pair_record(left: dict[str, Any], right: dict[str, Any], *, name: str) -> dict[str, Any]:
    if not left["success"] or not right["success"]:
        return {"pair": name, "pass": False, "reason": "condition_failed"}
    left_result = left["result"]
    right_result = right["result"]
    left_input = left_result["rec3_metrics"]["chat_template_input"]
    right_input = right_result["rec3_metrics"]["chat_template_input"]
    chat_token_ids_equal = left_input["token_ids"] == right_input["token_ids"]
    chat_token_sha256_equal = left_input["token_ids_sha256"] == right_input["token_ids_sha256"]
    generated_token_parity = left_result["generated_token_ids"] == right_result["generated_token_ids"]
    return {
        "pair": name,
        "raw_rendered_prompt_sha256_equal": (
            left_result["rec3_metrics"]["raw_rendered_prompt_sha256"]
            == right_result["rec3_metrics"]["raw_rendered_prompt_sha256"]
        ),
        "chat_template_input_token_count": left_input["token_count"],
        "chat_template_input_token_ids_sha256": left_input["token_ids_sha256"],
        "chat_template_input_token_ids_equal": chat_token_ids_equal,
        "chat_template_input_token_sha256_equal": chat_token_sha256_equal,
        "generated_token_parity": generated_token_parity,
        "left_output_tokens": left_result["output_tokens"],
        "right_output_tokens": right_result["output_tokens"],
        "pass": chat_token_ids_equal and chat_token_sha256_equal and generated_token_parity,
    }


def _input_quality_record(item: dict[str, Any], compressed_context: str, original_prompt: str, compressed_prompt: str) -> dict[str, Any]:
    evidence = list(item["expected_fields"].values())
    protected_byte_exact = (
        item["question"].encode("utf-8") in compressed_prompt.encode("utf-8")
        and compressed_prompt.endswith(item["output_instruction"])
        and original_prompt.split("\n\nQuestion:\n", 1)[1].encode("utf-8")
        == compressed_prompt.split("\n\nQuestion:\n", 1)[1].encode("utf-8")
    )
    evidence_once_input = all(item["context"].count(fragment) == 1 for fragment in evidence)
    evidence_retained = all(fragment in compressed_context for fragment in evidence)
    return {
        "protected_fields_byte_exact": protected_byte_exact,
        "question_sha256": _sha256_text(item["question"]),
        "instruction_sha256": _sha256_text(item["output_instruction"]),
        "required_evidence": evidence,
        "required_evidence_occurs_once_in_original_context": evidence_once_input,
        "required_evidence_retained_in_compressed_context": evidence_retained,
        "pass": protected_byte_exact and evidence_once_input and evidence_retained,
    }


def _output_quality_record(text: str, expected_fields: dict[str, str]) -> dict[str, Any]:
    strict_match = STRICT_OUTPUT_FORMAT.fullmatch(text)
    tolerant_match = TOLERANT_FIELD_FORMAT.search(text)
    parsed_fields = tolerant_match.groupdict() if tolerant_match else None
    field_matches = (
        {field: parsed_fields[field] == expected for field, expected in expected_fields.items()}
        if parsed_fields is not None else {field: False for field in expected_fields}
    )
    return {
        "format_compliant": strict_match is not None,
        "strict_format_pattern": STRICT_OUTPUT_FORMAT.pattern,
        "tolerant_field_pattern": TOLERANT_FIELD_FORMAT.pattern,
        "parsed_fields": parsed_fields,
        "expected_fields": expected_fields,
        "field_matches": field_matches,
        "exact_field_match": parsed_fields is not None and all(field_matches.values()),
    }


def _run_engine(
    *, condition: str, prompt_kind: str, prepared: list[dict[str, Any]], config: Rec2Config, lifecycle: list[dict[str, Any]],
) -> dict[str, Any]:
    engine_condition = "baseline" if condition in {"baseline-ar", "llmlingua-ar-r2"} else "dflash"
    workload_start = time.perf_counter()
    lifecycle.append({"event": "before_load", "condition": condition, "memory": _cuda_memory(f"before_{condition}_load")})
    engine = RuntimeEngine(config, condition=engine_condition)
    lifecycle.append({"event": "after_load", "condition": condition, "memory": _cuda_memory(f"after_{condition}_load")})
    try:
        warmup = prepared[0]["original_prompt"] if prompt_kind == "original" else prepared[0]["compressed_prompt"]
        warmup_result = _request_record(
            condition=condition, prompt_kind="warmup", prompt=warmup,
            compression=prepared[0]["compression"], engine=engine, lifecycle=lifecycle,
        )
        rows = {}
        for item in prepared:
            prompt = item["original_prompt"] if prompt_kind == "original" else item["compressed_prompt"]
            rows[item["prompt_id"]] = _request_record(
                condition=condition, prompt_kind=prompt_kind, prompt=prompt,
                compression=item["compression"], engine=engine, lifecycle=lifecycle,
            )
        return {"rows": rows, "warmup": warmup_result}
    finally:
        engine.close()
        lifecycle.append({"event": "after_close", "condition": condition, "memory": _cuda_memory(f"after_{condition}_close")})
        elapsed_ms = (time.perf_counter() - workload_start) * 1000.0
        lifecycle.append({
            "event": "condition_lifecycle_complete", "condition": condition,
            "workload_wall_clock_ms": elapsed_ms,
            "lifecycle_amortized_ms_per_measured_request": elapsed_ms / len(prepared),
            "scope": "engine load, one warmup, ten measured requests, and engine close",
        })


def _annotate_total_input_reduction(prompt_records: list[dict[str, Any]]) -> None:
    for prompt in prompt_records:
        runs = prompt["runs"]
        for original_condition in ("baseline-ar", "dflash-r1"):
            if runs[original_condition]["success"]:
                runs[original_condition]["result"]["rec3_metrics"]["total_input_token_reduction"] = None
        for compressed_condition, original_condition in (
            ("llmlingua-ar-r2", "baseline-ar"),
            ("cc-dflash-r2", "dflash-r1"),
        ):
            compressed_run = runs[compressed_condition]
            original_run = runs[original_condition]
            if not compressed_run["success"] or not original_run["success"]:
                continue
            original_tokens = original_run["result"]["rec3_metrics"]["chat_template_input"]["token_count"]
            compressed_tokens = compressed_run["result"]["rec3_metrics"]["chat_template_input"]["token_count"]
            compressed_run["result"]["rec3_metrics"]["total_input_token_reduction"] = (
                1 - (compressed_tokens / original_tokens) if original_tokens else 0.0
            )
            compressed_run["result"]["rec3_metrics"]["total_input_token_reduction_reference_condition"] = original_condition


def _weighted_dflash_metrics(prompt_records: list[dict[str, Any]], conditions: tuple[str, ...]) -> dict[str, Any] | None:
    counters = {
        "target_prefill_calls": 0, "target_verification_calls": 0, "target_single_token_calls": 0,
        "accepted_draft_tokens": 0, "draft_tokens_proposed": 0, "output_tokens": 0, "emitted_tokens": 0,
    }
    observed = 0
    for prompt in prompt_records:
        for condition in conditions:
            run = prompt["runs"][condition]
            if not run["success"] or run["result"]["dflash"] is None:
                continue
            observed += 1
            result = run["result"]
            dflash = result["dflash"]
            for key in ("target_prefill_calls", "target_verification_calls", "target_single_token_calls", "accepted_draft_tokens", "draft_tokens_proposed"):
                counters[key] += int(dflash[key])
            counters["output_tokens"] += int(result["output_tokens"])
            counters["emitted_tokens"] += sum(int(value) for value in dflash["acceptance_lengths"])
    if not observed:
        return None
    target_forwards = counters["target_prefill_calls"] + counters["target_verification_calls"] + counters["target_single_token_calls"]
    return {
        "measured_rows": observed,
        "counters": counters,
        "weighted_tau": counters["emitted_tokens"] / counters["target_verification_calls"] if counters["target_verification_calls"] else 0.0,
        "weighted_draft_acceptance_rate": counters["accepted_draft_tokens"] / counters["draft_tokens_proposed"] if counters["draft_tokens_proposed"] else 0.0,
        "target_forwards_per_output_token": target_forwards / counters["output_tokens"] if counters["output_tokens"] else 0.0,
        "formula_scope": f"counter totals across measured rows for {', '.join(conditions)}; excludes warmups",
    }


def _condition_metrics(prompt_records: list[dict[str, Any]], condition: str) -> dict[str, Any]:
    successful = [prompt["runs"][condition]["result"] for prompt in prompt_records if prompt["runs"][condition]["success"]]
    def values(key: str) -> list[float]:
        return [
            float(result["rec3_metrics"][key]) for result in successful
            if result["rec3_metrics"][key] is not None
        ]
    dflash_values = [result["dflash"] for result in successful if result["dflash"] is not None]
    reductions = [
        result["rec3_metrics"]["total_input_token_reduction"]
        for result in successful if result["rec3_metrics"]["total_input_token_reduction"] is not None
    ]
    return {
        "successful_requests": len(successful),
        "mean_chat_template_input_tokens": statistics.mean(result["rec3_metrics"]["chat_template_input"]["token_count"] for result in successful) if successful else None,
        "mean_context_reduction_rate_compressor_tokenizer": statistics.mean(values("context_reduction_rate")) if values("context_reduction_rate") else None,
        "mean_total_input_token_reduction_qwen_tokenizer": statistics.mean(reductions) if reductions else None,
        "p50_compression_latency_ms": statistics.median(values("compression_latency_ms")) if successful else None,
        "p50_prefill_latency_ms": statistics.median(values("prefill_latency_ms")) if successful else None,
        "p50_decode_latency_ms": statistics.median(values("decode_latency_ms")) if successful else None,
        "p50_generation_latency_ms": statistics.median(values("generation_latency_ms")) if successful else None,
        "p50_stage_sum_warm_e2e_ms": statistics.median(values("stage_sum_warm_e2e_ms")) if successful else None,
        "p50_decode_tok_s": statistics.median(values("decode_tok_s")) if successful else None,
        "mean_output_tokens": statistics.mean(result["output_tokens"] for result in successful) if successful else None,
        "cap_hit_count": sum(bool(result["rec3_metrics"]["cap_hit"]) for result in successful),
        "max_full_request_peak_reserved_bytes": max((result["rec3_metrics"]["full_request_peak_vram"]["peak_reserved_bytes"] for result in successful), default=None),
        "format_compliance": sum(prompt["output_quality"][condition]["format_compliant"] for prompt in prompt_records),
        "exact_field_quality": sum(prompt["output_quality"][condition]["exact_field_match"] for prompt in prompt_records),
        "mean_dflash_tau_unweighted": statistics.mean(item["effective_tau"] for item in dflash_values) if dflash_values else None,
        "mean_draft_acceptance_rate_unweighted": statistics.mean(item["draft_acceptance_rate"] for item in dflash_values) if dflash_values else None,
        "weighted_dflash": _weighted_dflash_metrics(prompt_records, (condition,)),
    }


def _global_dflash_metrics(prompt_records: list[dict[str, Any]]) -> dict[str, Any]:
    combined = _weighted_dflash_metrics(prompt_records, ("dflash-r1", "cc-dflash-r2"))
    if combined is None:
        raise RuntimeError("global D-Flash metrics require successful D-Flash rows")
    return combined


def _metric_validity(prompt_records: list[dict[str, Any]]) -> dict[str, Any]:
    checks: list[bool] = []
    for prompt in prompt_records:
        for condition, run in prompt["runs"].items():
            if not run["success"]:
                checks.append(False)
                continue
            result = run["result"]
            metrics = result["rec3_metrics"]
            chat_input = metrics["chat_template_input"]
            context_formula = (
                metrics["context_reduction_rate"] is None
                and metrics["context_original_tokens"] is None
                and metrics["context_compressed_tokens"] is None
                if condition in {"baseline-ar", "dflash-r1"}
                else metrics["context_reduction_rate"]
                == 1 - (metrics["context_compressed_tokens"] / metrics["context_original_tokens"])
            )
            stage_formula = metrics["stage_sum_warm_e2e_ms"] == (
                metrics["compression_latency_ms"] + result["timing"]["warm_request_ms"]
            )
            token_count_match = chat_input["token_count"] == result["prompt_tokens"] == len(chat_input["token_ids"])
            tokenizer_hash_match = chat_input["token_ids_sha256"] == _token_ids_sha256(chat_input["token_ids"])
            if condition in {"baseline-ar", "dflash-r1"}:
                qwen_reduction_valid = metrics["total_input_token_reduction"] is None
            else:
                reference = prompt["runs"][metrics["total_input_token_reduction_reference_condition"]]
                reference_count = reference["result"]["rec3_metrics"]["chat_template_input"]["token_count"]
                qwen_reduction_valid = metrics["total_input_token_reduction"] == (
                    1 - (chat_input["token_count"] / reference_count)
                )
            checks.append(context_formula and stage_formula and token_count_match and tokenizer_hash_match and qwen_reduction_valid)
    return {"checked_rows": len(checks), "valid_rows": sum(checks), "pass": bool(checks) and all(checks)}


def main() -> None:
    if not torch.cuda.is_available():
        raise RuntimeError("REC-3 four-condition validation requires CUDA")
    original_config = load_config(ROOT / "config.yml")
    config = _mock_config(original_config)
    fixtures = [_fixture(index, *case) for index, case in enumerate(CASES, start=1)]
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    FIXTURES_OUTPUT.write_text(json.dumps([_json_fixture(item) for item in fixtures], indent=2, sort_keys=True) + "\n", encoding="utf-8")

    workload_start = time.perf_counter()
    lifecycle: list[dict[str, Any]] = [{"event": "start", "memory": _cuda_memory("start")}]
    compressor = LLMLinguaCompressor(
        config.path_for("models.compressor.local_path"),
        reserved_vram_budget_gib=float(config.require("models.compressor.reserved_budget_gib")),
    )
    lifecycle.append({"event": "compressor_loaded", "memory": _cuda_memory("compressor_loaded")})
    prepared: list[dict[str, Any]] = []
    try:
        for item in fixtures:
            protocol = item["protocol"]
            synchronize()
            compression = compressor.compress(protocol, COMPRESSION_CONFIG)
            synchronize()
            compressed_prompt = protocol.render(compression.compressed_context)
            original_prompt = protocol.render(protocol.context)
            input_quality = _input_quality_record(item, compression.compressed_context, original_prompt, compressed_prompt)
            prepared.append({
                **_json_fixture(item),
                "original_prompt": original_prompt,
                "compressed_prompt": compressed_prompt,
                "original_prompt_sha256": _sha256_text(original_prompt),
                "compressed_prompt_sha256": _sha256_text(compressed_prompt),
                "compression": {
                    "context_tokenizer": str(getattr(compressor.tokenizer, "name_or_path", compressor.model_path)),
                    "original_tokens": compression.original_tokens,
                    "compressed_tokens": compression.compressed_tokens,
                    "reduction_rate": compression.reduction_rate,
                    "compression_latency_ms": compression.compression_latency_ms,
                    "peak_allocated_vram_bytes": compression.peak_allocated_vram_bytes,
                    "peak_reserved_vram_bytes": compression.peak_reserved_vram_bytes,
                    "reserved_vram_budget_bytes": compression.reserved_vram_budget_bytes,
                    "reserved_vram_budget_pass": compression.reserved_vram_budget_pass,
                    "chunk_count": compression.chunk_count,
                    "input_word_count": compression.input_word_count,
                    "submitted_word_count": compression.submitted_word_count,
                },
                "input_quality": input_quality,
            })
    finally:
        compressor.close()
        lifecycle.append({"event": "compressor_closed", "memory": _cuda_memory("compressor_closed")})

    condition_runs: dict[str, dict[str, Any]] = {}
    for condition, prompt_kind in (
        ("baseline-ar", "original"), ("dflash-r1", "original"),
        ("llmlingua-ar-r2", "compressed"), ("cc-dflash-r2", "compressed"),
    ):
        condition_runs[condition] = _run_engine(
            condition=condition, prompt_kind=prompt_kind, prepared=prepared, config=config, lifecycle=lifecycle,
        )

    prompt_records = []
    for item in prepared:
        prompt_id = item["prompt_id"]
        runs = {condition: condition_runs[condition]["rows"][prompt_id] for condition in CONDITIONS}
        output_quality = {
            condition: _output_quality_record(run["result"]["text"], item["expected_fields"])
            if run["success"] else {
                "format_compliant": False, "parsed_fields": None, "expected_fields": item["expected_fields"],
                "field_matches": {field: False for field in item["expected_fields"]}, "exact_field_match": False,
            }
            for condition, run in runs.items()
        }
        pairs = [
            _pair_record(runs["baseline-ar"], runs["dflash-r1"], name="original_baseline_ar_vs_dflash_r1"),
            _pair_record(runs["llmlingua-ar-r2"], runs["cc-dflash-r2"], name="compressed_llmlingua_ar_r2_vs_cc_dflash_r2"),
        ]
        prompt_records.append({**item, "runs": runs, "pair_token_parity": pairs, "output_quality": output_quality})

    _annotate_total_input_reduction(prompt_records)
    all_runs = [run for prompt in prompt_records for run in prompt["runs"].values()]
    all_pairs = [pair for prompt in prompt_records for pair in prompt["pair_token_parity"]]
    input_protocol_count = sum(prompt["input_quality"]["pass"] for prompt in prompt_records)
    pair_pass_count = sum(pair["pass"] for pair in all_pairs)
    condition_success_count = sum(run["success"] for run in all_runs)
    output_quality_count = sum(
        result["exact_field_match"] for prompt in prompt_records for result in prompt["output_quality"].values()
    )
    output_format_count = sum(
        result["format_compliant"] for prompt in prompt_records for result in prompt["output_quality"].values()
    )
    metric_validity = _metric_validity(prompt_records)
    workload_wall_clock_ms = (time.perf_counter() - workload_start) * 1000.0
    protocol_pass = (
        input_protocol_count == len(prompt_records)
        and pair_pass_count == len(all_pairs)
        and condition_success_count == len(all_runs)
        and compressor.device_audit["all_tensors_cuda"]
    )
    quality_pass = output_quality_count == len(all_runs)
    metric_validity_pass = bool(metric_validity["pass"])
    summary = {
        "protocol_pass": protocol_pass,
        "quality_pass": quality_pass,
        "metric_validity_pass": metric_validity_pass,
        "overall_pass": protocol_pass and quality_pass and metric_validity_pass,
        "input_protocol_protected_and_evidence": f"{input_protocol_count}/{len(prompt_records)}",
        "pair_token_parity": f"{pair_pass_count}/{len(all_pairs)}",
        "condition_success": f"{condition_success_count}/{len(all_runs)}",
        "output_format_compliance": f"{output_format_count}/{len(all_runs)}",
        "output_exact_field_quality": f"{output_quality_count}/{len(all_runs)}",
        "metric_validity": metric_validity,
        "conditions": {condition: _condition_metrics(prompt_records, condition) for condition in CONDITIONS},
        "global_dflash": _global_dflash_metrics(prompt_records),
        "workload": {
            "workload_wall_clock_ms": workload_wall_clock_ms,
            "lifecycle_amortized_ms_per_measured_request": workload_wall_clock_ms / len(all_runs),
            "measured_request_count": len(all_runs),
            "scope": "compressor load/compress/unload plus four engine lifecycles, each with one warmup and ten measured requests",
        },
    }
    payload = {
        "validation_version": "ccdf.rec3-four-condition-mock10.v2",
        "protocol": {
            "conditions": {
                "baseline-ar": "original prompt + AR", "dflash-r1": "original prompt + D-Flash",
                "llmlingua-ar-r2": "compressed prompt + AR", "cc-dflash-r2": "compressed prompt + D-Flash",
            },
            "context_only_compression": True,
            "question_and_instruction_byte_exact": True,
            "fixture_contract": "Frozen REC-3 mock10 fixture cases; validation does not alter fixtures to obtain passing output quality.",
            "system_prompt": NEUTRAL_SYSTEM_PROMPT,
            "system_prompt_sha256": _sha256_text(NEUTRAL_SYSTEM_PROMPT),
            "max_new_tokens": MAX_NEW_TOKENS,
            "temperature": 0.0,
            "cuda_synchronize_before_after_each_measured_request": True,
            "no_runtime_override": {
                "sdpa_kernel": config.require("runtime.sdpa_kernel"),
                "decode_temperature": config.require("runtime.temperature"),
                "block_policy": config.require("optimization.block_policy"),
                "gpu_resident_acceptance": config.require("optimization.gpu_resident_acceptance"),
            },
        },
        "metric_formulas": {
            "context_reduction_rate": "1 - compressed_context_tokens / original_context_tokens, counted by the LLMLingua compressor tokenizer",
            "total_input_token_reduction": "1 - compressed Qwen chat-template token count / paired original Qwen chat-template token count; null for original conditions",
            "stage_sum_warm_e2e_ms": "compression_latency_ms (compressed conditions only) + synchronized production warm_request_ms; not a wall-clock workload metric",
            "workload_wall_clock_ms": "wall clock for the entire validation workload including lifecycle work and warmups",
            "lifecycle_amortized_ms_per_measured_request": "workload_wall_clock_ms / 40 measured requests",
            "decode_tok_s": "max(output_tokens - 1, 0) / (decode_total_ms / 1000)",
            "global_weighted_tau": "sum(acceptance_lengths) / sum(target_verification_calls)",
            "global_weighted_draft_acceptance_rate": "sum(accepted_draft_tokens) / sum(draft_tokens_proposed)",
            "global_target_forwards_per_output_token": "sum(target_prefill_calls + target_verification_calls + target_single_token_calls) / sum(output_tokens)",
        },
        "environment": _gpu_environment(),
        "compressor": {"model_contract": compressor.model_contract, "device_audit": compressor.device_audit},
        "lifecycle": lifecycle,
        "prompts": prompt_records,
        "summary": summary,
    }
    RAW_OUTPUT.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    SUMMARY_OUTPUT.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(summary, sort_keys=True))
    if not summary["overall_pass"]:
        raise SystemExit("REC-3 protocol has failing quality or validity gates")


if __name__ == "__main__":
    main()
