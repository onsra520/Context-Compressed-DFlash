import importlib
import sys
import types

import torch


class FakeDynamicCache:
    def __init__(self):
        self.length = 0

    def get_seq_length(self):
        return self.length

    def crop(self, length):
        self.length = int(length)


# The runtime dependency is not installed in the artifact build container.
# Supply only the cache contract needed by this CPU integration test.
sys.modules.setdefault("transformers", types.SimpleNamespace(DynamicCache=FakeDynamicCache))

generate_module = importlib.import_module("ccdf.dflash.generate")
verifier_module = importlib.import_module("ccdf.dflash.verifier")
# Other tests can import the real Transformers package first, making the
# setdefault shim above ineffective. Keep this CPU test's explicit fake cache
# contract independent of module import order.
verifier_module.DynamicCache = FakeDynamicCache
policy_module = importlib.import_module("ccdf.dflash.policy")
schemas_module = importlib.import_module("ccdf.schemas")


class Output:
    def __init__(self, logits, hidden_states):
        self.logits = logits
        self.hidden_states = hidden_states


class Embed(torch.nn.Module):
    def __init__(self, vocab):
        super().__init__()
        self.vocab = vocab

    def forward(self, input_ids):
        return torch.nn.functional.one_hot(input_ids, self.vocab).float()


class Target(torch.nn.Module):
    def __init__(self, vocab=32):
        super().__init__()
        self.anchor = torch.nn.Parameter(torch.zeros(1))
        self.vocab = vocab
        self.model = types.SimpleNamespace(embed_tokens=Embed(vocab))
        self.lm_head = torch.nn.Identity()

    @property
    def device(self):
        return self.anchor.device

    def forward(self, input_ids, past_key_values, **kwargs):
        past_key_values.length += int(input_ids.shape[1])
        predicted = (input_ids + 1) % self.vocab
        logits = torch.nn.functional.one_hot(predicted, self.vocab).float()
        hidden = torch.nn.functional.one_hot(input_ids, self.vocab).float()
        return Output(logits, (hidden, hidden))


class Drafter(torch.nn.Module):
    def __init__(self, vocab=32):
        super().__init__()
        self.anchor = torch.nn.Parameter(torch.zeros(1))
        self.vocab = vocab
        self.block_size = 4
        self.mask_token_id = 0
        self.target_layer_ids = [0]

    def forward(self, noise_embedding, position_ids, past_key_values, **kwargs):
        assert noise_embedding.dtype == self.anchor.dtype
        assert kwargs["target_hidden"].dtype == self.anchor.dtype
        seed = noise_embedding[:, 0].argmax(dim=-1)
        block = noise_embedding.shape[1]
        ids = torch.stack([(seed + index) % self.vocab for index in range(block)], dim=1)
        past_key_values.length = int(position_ids[0, -1].item()) + 1
        return torch.nn.functional.one_hot(ids, self.vocab).float()


class Tokenizer:
    def decode(self, token_ids, skip_special_tokens=True):
        return " ".join(str(value) for value in token_ids)


def test_dflash_loop_advances_by_verified_blocks(monkeypatch):
    monkeypatch.setattr(generate_module, "synchronize", lambda *args, **kwargs: None)
    monkeypatch.setattr(
        generate_module,
        "collect_memory",
        lambda limit_gib: schemas_module.MemoryStats(limit_bytes=6, gate_pass=True),
    )
    monkeypatch.setattr(generate_module, "enforce_memory_gate", lambda stats, label: None)
    settings = schemas_module.GenerationSettings(
        max_new_tokens=9,
        temperature=0.0,
        stop_token_ids=(99,),
        dataset="general",
        block_size=4,
    )
    policy = policy_module.BlockPolicy(
        mode="fixed",
        fixed_block_size=4,
        allowed_block_sizes=(4,),
        rolling_window=4,
        low_tau_threshold=2.5,
        high_tau_threshold=4.5,
        low_tau_block_size=4,
        mid_tau_block_size=4,
        high_tau_block_size=4,
    )
    result = generate_module.generate_dflash(
        Target(),
        Drafter(),
        Tokenizer(),
        torch.tensor([[1]], dtype=torch.long),
        settings,
        model_metadata={},
        block_policy=policy,
        memory_limit_gib=6.0,
        compact_structural_audit=True,
    )
    assert result.generated_token_ids == [2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert result.dflash.acceptance_lengths == [4, 4]
    assert result.dflash.effective_tau == 4.0
    assert result.dflash.target_verification_calls == 2
    assert all(item["structural_pass"] for item in result.dflash.structural_audit)
